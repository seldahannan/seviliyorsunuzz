
const answers = { q1:'c', q2:'abc', q3:'b' };

function check(correct,next,key){
  if(correct === answers[key]) localStorage.setItem(key,'1');
  else localStorage.setItem(key,'0');
  window.location = next;
}

function finish(){
  const ok = localStorage.getItem('q1')==='1' &&
            localStorage.getItem('q2')==='1' &&
            localStorage.getItem('q3')==='1';
  localStorage.setItem('ok', ok);
  window.location = 'result.html';
}
